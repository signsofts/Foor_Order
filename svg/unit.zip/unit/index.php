<?php
    header('location:./login/login.php');
?>